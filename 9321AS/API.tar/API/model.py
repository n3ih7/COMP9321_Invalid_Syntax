def mechanical(v):
    return 1
