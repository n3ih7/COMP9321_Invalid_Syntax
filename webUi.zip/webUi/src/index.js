import initApp from './main.js';
API_URL = 'http://127.0.0.1:5000'
//import API_URL from './backend_url.js';

initApp(API_URL);
